<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       http://stephenafamo.com
 * @since      1.0.0
 *
 * @package    Woocommerce_Global_Cart
 * @subpackage Woocommerce_Global_Cart/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Woocommerce_Global_Cart
 * @subpackage Woocommerce_Global_Cart/includes
 * @author     Stephen Afam-Osemene <stephenafamo@gmail.com>
 */
class Woocommerce_Global_Cart_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'woocommerce-global-cart',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
