<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://stephenafamo.com
 * @since      1.0.0
 *
 * @package    Woocommerce_Global_Cart
 * @subpackage Woocommerce_Global_Cart/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Woocommerce_Global_Cart
 * @subpackage Woocommerce_Global_Cart/includes
 * @author     Stephen Afam-Osemene <stephenafamo@gmail.com>
 */
class Woocommerce_Global_Cart_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
