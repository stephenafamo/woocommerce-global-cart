<?php

/**
 * Fired during plugin activation
 *
 * @link       http://stephenafamo.com
 * @since      1.0.0
 *
 * @package    Woocommerce_Global_Cart
 * @subpackage Woocommerce_Global_Cart/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Woocommerce_Global_Cart
 * @subpackage Woocommerce_Global_Cart/includes
 * @author     Stephen Afam-Osemene <stephenafamo@gmail.com>
 */
class Woocommerce_Global_Cart_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
